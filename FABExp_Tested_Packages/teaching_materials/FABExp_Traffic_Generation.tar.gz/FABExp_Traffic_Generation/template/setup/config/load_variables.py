# This file defines the variables to be used
slice_name = 'TrafficGeneration'
notebook_name = 'TrafficGeneration.ipynb'