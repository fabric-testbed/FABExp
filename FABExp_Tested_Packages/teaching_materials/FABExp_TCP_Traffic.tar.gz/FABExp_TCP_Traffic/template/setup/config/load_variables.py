# This file defines the variables to be used
slice_name = 'TCP_Traffic_Introduction' 
notebook_name = 'TCP_Traffic.ipynb'