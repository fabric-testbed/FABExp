# This file defines the variables to be used
slice_name = 'MyWebServerSlice'
notebook_name = 'webserver.ipynb'