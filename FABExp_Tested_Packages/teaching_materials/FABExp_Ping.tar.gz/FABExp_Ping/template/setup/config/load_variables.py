# This file defines the variables to be used
slice_name = 'MyLayer2PingSlice'
notebook_name = 'Ping.ipynb'