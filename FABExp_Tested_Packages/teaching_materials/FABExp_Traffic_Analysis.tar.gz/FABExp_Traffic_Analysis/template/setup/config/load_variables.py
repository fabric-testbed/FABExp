# This file defines the variables to be used
slice_name = 'TrafficAnalysis'
notebook_name = 'Traffic_Analysis.ipynb'