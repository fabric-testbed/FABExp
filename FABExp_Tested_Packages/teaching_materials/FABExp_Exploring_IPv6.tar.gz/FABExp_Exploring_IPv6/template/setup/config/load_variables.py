# This file defines the variables to be used
slice_name = 'IPv6'
notebook_name = 'ExploringIPV6.ipynb'