# This file defines the variables to be used
slice_name = 'RttWindowTCP' 
notebook_name = 'RTTandWindowSizeonTCP.ipynb'