# This file defines the variables to be used
slice_name = 'IPv4_Routing'
notebook_name = 'RoutingWithIPv4.ipynb'