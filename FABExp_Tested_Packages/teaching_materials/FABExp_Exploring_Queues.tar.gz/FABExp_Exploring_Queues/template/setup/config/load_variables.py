# This file defines the variables to be used
slice_name = 'ExploringQueues' 
notebook_name = 'ExploringQueues.ipynb'