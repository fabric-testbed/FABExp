# This file defines the variables to be used
slice_name = 'MySlice1'
notebook_name = 'main.ipynb'